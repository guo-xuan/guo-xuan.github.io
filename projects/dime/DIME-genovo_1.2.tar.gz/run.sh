#!/bin/sh

getVariable(){
	local yes=0
	cat config.txt | while read LINE
	do
		if [ "$LINE" == "$1" ]; then
			yes=1
			continue
		fi
		if [ $yes -eq 1 ]; then
			echo "$LINE"
			break
		fi
	done
}

fileName=""
NumReads=0
NumberOfMappers=0

fileName=$(getVariable [DataFileName])
NumReads=$(getVariable [NumberOfReads])
NumberOfMappers=$(getVariable [NumberOfMappers])

if [ -d ./TEMP ]; then
	rm -r ./TEMP/* >>log
else
	mkdir ./TEMP
fi

if [ -d ./TEMP/tmp ]; then
	rm ./TEMP/tmp/* >>log
else
	mkdir ./TEMP/tmp
fi

if [ -f log ]; then
	rm log
fi
echo "Starting changing format"
#step02 is used to change the format
java -jar ./Programs/step02.jar $fileName $NumReads $NumberOfMappers ./TEMP/tmp/ DIME >>log

Hadoop=$(getVariable [PathOfHadoopBin])

$Hadoop/stop-all.sh >>log
echo "Starting Hadoop"
$Hadoop/start-all.sh >>log
$Hadoop/hadoop dfsadmin -safemode leave >>log
$Hadoop/hadoop fs -rmr Splits >>log
$Hadoop/hadoop fs -mkdir Splits >>log
echo "Copying files to HDFS"
$Hadoop/hadoop fs -copyFromLocal ./TEMP/tmp/* Splits >>log
rm ./TEMP/tmp/* >>log
echo "Starting WEC"
#step03 is used to do the WEC
LengthLmerR=$(getVariable [LmerForWEC])
NumM=$(getVariable [NumberOfM])
$Hadoop/hadoop jar ./Programs/step03.jar Splits Edges nMap $NumberOfMappers nRed $NumberOfMappers numReads $NumReads Lmer $LengthLmerR Prefix DIME M $NumM >>log
$Hadoop/hadoop fs -copyToLocal EdgesDump/* ./TEMP/tmp >>log

if [ -d ./TEMP/tmpSorted ]; then
	rm ./TEMP/tmpSorted/* >>log
else
	mkdir ./TEMP/tmpSorted
fi
#step04 is used to sorted the result from WEC
java -jar ./Programs/step04.jar ./TEMP/tmp ./TEMP/tmpSorted/ $NumReads >>log

NumberOfClusters=$(getVariable [NumberOfClusters])
if [ -d ./TEMP/clusters ]; then
	rm ./TEMP/clusters/* >>log
else
	mkdir ./TEMP/clusters
fi
rm ./TEMP/ClusterInfo >>log
#step05 is used to cluster
java -jar ./Programs/step05.jar ./TEMP/tmpSorted ./TEMP/ClusterInfo $NumReads $NumberOfClusters $fileName ./TEMP/clusters/ >>log
rm ./TEMP/temp.txt >>log
rm temp.txt >>log

if [ -d ./TEMP/LocalMapTasks ]; then
	rm ./TEMP/LocalMapTasks/* >>log
else
	mkdir ./TEMP/LocalMapTasks
fi

NumLocalAssembly=$(getVariable [NumLocalAssembly])
NumIteration=$(getVariable [NumberOfIterations])
#step06 is used to create tasks for local-assembly
java -jar ./Programs/step06.jar genovo ./TEMP/clusters ./TEMP/LocalMapTasks $NumLocalAssembly $NumIteration
cp ./Programs/genovo ./TEMP/clusters/

$Hadoop/hadoop dfsadmin -safemode leave >>log
$Hadoop/hadoop fs -rmr Splits/* >>log
$Hadoop/hadoop fs -copyFromLocal ./TEMP/LocalMapTasks/* Splits >>log
cd ./TEMP/clusters
dir=$(pwd)
cd ../../

#step07 is used to run local-assembly
echo "Starting the Local-Assembly"
$Hadoop/hadoop jar ./Programs/step07.jar Splits Output paraDir $dir>>log

if [ -d ./TEMP/GenovoResult ]; then
	rm ./TEMP/GenovoResult/* >>log
else
	mkdir ./TEMP/GenovoResult
fi

mv ./TEMP/clusters/*.best ./TEMP/GenovoResult
#$Hadoop/hadoop fs -copyToLocal Output/* ./TEMP/GenovoResult

if [ -d ./TEMP/GenovoHadoop ]; then
	rm ./TEMP/GenovoHadoop/* >>log
else
	mkdir ./TEMP/GenovoHadoop
fi

echo "Starting the Merging"
#step08 is used to change the result of local-assembly to hadoop acceptable format
NumberOfClusters=$(./Programs/step08.jar ./TEMP/GenovoResult ./TEMP/GenovoHadoop/)

$Hadoop/hadoop dfsadmin -safemode leave >>log
$Hadoop/hadoop fs -rmr Splits/* >>log
#$Hadoop/hadoop fs -mkdir Splits >>log
$Hadoop/hadoop fs -copyFromLocal ./TEMP/GenovoHadoop/* Splits >>log

LengthLmerC=$(getVariable [LmerForMerging])
#step09 is used to run WEC for contigs
$Hadoop/hadoop jar ./Programs/step09.jar Splits Output nMap $NumberOfMappers nRed $NumberOfMappers numReads $NumberOfClusters Lmer $LengthLmerC Prefix part>>log

if [ -d ./TEMP/BeforeMerge ]; then
	rm ./TEMP/BeforeMerge/* >>log
else
	mkdir ./TEMP/BeforeMerge >>log
fi
$Hadoop/hadoop fs -copyToLocal Output/* ./TEMP/BeforeMerge >>log

if [ -d ./TEMP/ReadInfo ]; then
	rm ./TEMP/ReadInfo/* >>log
else
	mkdir ./TEMP/ReadInfo >>log
fi
find ./TEMP/clusters/ -type f ! -name "*.*" -exec mv -f {} ./TEMP/ReadInfo/ \;
rm ./TEMP/ReadInfo/genovo

#step10 is the merging
java -jar ./Programs/step10.jar ./TEMP/GenovoResult ./TEMP/BeforeMerge ./contig $NumberOfClusters ./TEMP/ReadInfo >>log

#clean up
rm -r ./TEMP/*
