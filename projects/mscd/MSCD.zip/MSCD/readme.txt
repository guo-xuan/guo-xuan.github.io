The software is programmed by C#.
Please run the following command for your data.

MSCD.exe calculatePValue cases.txt controls.txt
MSCD.exe searchMSCs cases.txt controls.txt
MSCD.exe extract cases.txt controls.txt


Step 1: 
MSCD.exe calculatePValue cases.txt controls.txt
The step is to compute the p-value matrix and threshold(Bonferroni correction).
You can use your p-value matrix and set the threshold manually before the step 2.


Step 2:
MSCD.exe searchMSCs cases.txt controls.txt


Step3:
MSCD.exe extract cases.txt controls.txt
TypicalMSCscases.txt and TypicalMSCscontrols.txt are the extracted typical MSCs.
TypicalMSCsByEveryExperiment.txt are some measurements of these MSCs. 



The formation of the data file is like the following. Each row the data is a SNP vector of one individual. 0,1,2 represent the number of major alleles. 3 represents unknown.
0000100200111101000
0020102120000001001
1001012031100002000
