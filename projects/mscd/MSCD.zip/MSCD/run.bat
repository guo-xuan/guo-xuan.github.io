MSCD.exe calculatePValue cases.txt controls.txt
MSCD.exe searchMSCs cases.txt controls.txt
MSCD.exe extract cases.txt controls.txt