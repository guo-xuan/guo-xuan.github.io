MSCD.exe extract cases_1.txt controls_1.txt
